import static org.junit.Assert.*;
import java.util.concurrent.TimeUnit;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;


public class LoginPariPassu{
	
	private static WebDriver driver;

@Test
public void setUpTest(){
	
	System.setProperty("webdriver.gecko.driver", "C:/geckodriver/geckodriver.exe");
	
	//acessando o site
	driver = new FirefoxDriver();
	driver.get("https://acesso.paripassu.com.br/#/login");
	
	//preenchendo login e senha e entrando
	driver.findElement(By.id("usuario")).sendKeys("brenda.nunes23@gmail.com");
	driver.findElement(By.id("password")).sendKeys("brenda230994");
	driver.findElement(By.id("submit-login")).click();
	
	
	//Acessando sistema clicq
	driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
	driver.findElement(By.id("sistemaComAcesso_54")).click(); 
	
  }
}




