import static org.junit.Assert.*;
import java.util.concurrent.TimeUnit;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Questionario {

	private static WebDriver driver; 
		
	@Test
	public void setUpTest() {
		
		System.setProperty("webdriver.gecko.driver", "C:/geckodriver/geckodriver.exe");
		
		//acessando o site
		driver = new FirefoxDriver();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.get("https://acesso.paripassu.com.br/#/login");
		
		//preenchendo login e senha e entrando
		driver.findElement(By.id("usuario")).sendKeys("brenda.nunes23@gmail.com");
		driver.findElement(By.id("password")).sendKeys("brenda230994");
		driver.findElement(By.id("submit-login")).click();
		
		//Acessando sistema clicq
		driver.findElement(By.id("sistemaComAcesso_54")).click(); 
		
		//acessando a lista de questionarios
		driver.findElement(By.cssSelector(".dropdown.ng-scope")).click();
		driver.findElement(By.linkText("Nova aplica��o de question�rio")).click();
		
		//Acessando Analista de qualidade
		driver.findElement(By.cssSelector(".list-group-item")).click();
		
		//Acessando Teste de QA
		driver.findElement(By.cssSelector(".list-group-item.list-group-item-buttom")).click();
		
		//Informando nome 
		driver.findElement(By.cssSelector(".input-full.form-control")).sendKeys("Brenda Santos Nunes");
	
		//Informando e-mail
		driver.findElement(By.cssSelector(".input-full.form-control.ng-pristine")).sendKeys("brenda.nunes23@gmail.com");
		
		//avan�ando question�rio
		driver.findElement(By.cssSelector(".glyphicon.glyphicon-chevron-right")).click();
		
		//respondendo pergunta 1
		driver.findElement(By.cssSelector(".input-full.form-control")).sendKeys("Porque acredito que eu e esta empresa juntas podemos ir al�m, alcan�ar voos longos e altos. Fazendo com que ambas cres�amos juntas.");
		
		//Respondendo pergunta 2
		driver.findElement(By.cssSelector(".input-full.form-control.ng-pristine")).sendKeys("Porque acredito que o QA � o medidor do software, ficamos entre o desenvolvimento e o cliente, temos como miss�o realizar o filtro do sistema para que ele atenda o cliente da melhor forma poss�vel. Isso me atrai, o desafio de conseguir entregar algo que realmente possa atender as necessidades de algu�m.");
	
		//Respondendo pergunta 3
		driver.findElement(By.cssSelector(".input-full.form-control.ng-pristine.ng-valid")).sendKeys("Tranquilamente, sempre busco uma solu��o ou sa�da r�pida para conseguir resolver o problema.");
		
		//salvando questionario 
		driver.findElement(By.cssSelector(".mb-sm.btn.btn-primary.ng-binding")).click(); 
		
		//Clicando na engrenagem para sair do sistema
		driver.findElement(By.id("dropdownMenu2")).click();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
		//Saindo do sistema
		driver.findElement(By.cssSelector(".ng-binding")).click();
		
	}
}
